import wikipedia
import html2text

# l2 =["Passion emotion","Pity","Pleasure","Pride","Rage emotion","Regret","social Rejection","Resentment","Self-confidence","Shame","Shyness", "sorrow emotion","Suffering","Surprise emotion","Trust emotion","Worry"]

# for x in l2:
   
print("Enter topic name: ")
x = input()
l = wikipedia.search(x)
print(l[0])
p = wikipedia.page(l[0])

print("choose a page(zero indexing): ")
y = int(input())

f =open(p.title +".txt", "w+")

f.write(html2text.html2text(p.content))

print("Content copied to", str(p.title), ".txt")

f.close